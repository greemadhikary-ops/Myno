import {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  SlashCommandBuilder,
  REST,
  Routes,
  ChatInputCommandInteraction,
  GuildMember,
  VoiceChannel,
  ColorResolvable,
} from 'discord.js';
import {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  NoSubscriberBehavior,
  VoiceConnectionStatus,
  getVoiceConnection,
} from '@discordjs/voice';
import { stream, video_info, search } from 'play-dl';

// ─── Types ───────────────────────────────────────────────────

interface QueueItem {
  title: string;
  url: string;
  duration: string;
  durationSec: number;
  thumbnail: string;
  requestedBy: string;
  requestedByAvatar: string;
}

interface ServerQueue {
  queue: QueueItem[];
  isPlaying: boolean;
  isPaused: boolean;
  loop: 'off' | 'song' | 'queue';
  volume: number;
  currentTrack: QueueItem | null;
  textChannel: string;
  voiceChannel: string;
}

// ─── Config ──────────────────────────────────────────────────

const CONFIG = {
  token: process.env.BOT_TOKEN || '',
  clientId: process.env.CLIENT_ID || '',
  prefix: '!',
  color: '#5865F2' as ColorResolvable,
  stayInChannel: true,
  maxQueueSize: 50,
};

// ─── Validate ────────────────────────────────────────────────

if (!CONFIG.token) {
  console.error('❌ BOT_TOKEN is required in .env');
  process.exit(1);
}

// ─── State ───────────────────────────────────────────────────

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ],
});

const servers = new Map<string, ServerQueue>();
const players = new Map<string, ReturnType<typeof createAudioPlayer>>();
const connections = new Map<string, ReturnType<typeof getVoiceConnection>>();

// ─── Helpers ─────────────────────────────────────────────────

function getServerQueue(guildId: string): ServerQueue {
  if (!servers.has(guildId)) {
    servers.set(guildId, {
      queue: [],
      isPlaying: false,
      isPaused: false,
      loop: 'off',
      volume: 100,
      currentTrack: null,
      textChannel: '',
      voiceChannel: '',
    });
  }
  return servers.get(guildId)!;
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function createEmbed(title: string, description: string, color?: ColorResolvable): EmbedBuilder {
  return new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(color || CONFIG.color)
    .setTimestamp();
}

function nowPlayingEmbed(track: QueueItem, queueLength: number): EmbedBuilder {
  return new EmbedBuilder()
    .setTitle('🎵 Now Playing')
    .setColor('#1DB954' as ColorResolvable)
    .setThumbnail(track.thumbnail)
    .addFields(
      { name: 'Title', value: track.title.length > 80 ? track.title.substring(0, 80) + '...' : track.title, inline: false },
      { name: 'Duration', value: track.duration, inline: true },
      { name: 'Requested By', value: `<@${track.requestedBy}>`, inline: true },
      { name: 'Queue', value: `${queueLength} more song${queueLength !== 1 ? 's' : ''} in queue`, inline: true },
    )
    .setFooter({ text: '🎵 YouTube Music Bot' })
    .setTimestamp();
}

function queueListEmbed(queue: QueueItem[], page: number): EmbedBuilder {
  const perPage = 10;
  const start = (page - 1) * perPage;
  const end = start + perPage;
  const items = queue.slice(start, end);

  const description = items.length === 0
    ? 'Queue is empty!'
    : items.map((item, i) => {
        const num = start + i + 1;
        return `${num}. [${item.title}](${item.url}) \`[${item.duration}]\` — <@${item.requestedBy}>`;
      }).join('\n');

  return new EmbedBuilder()
    .setTitle('📋 Music Queue')
    .setDescription(description)
    .setColor(CONFIG.color)
    .setFooter({
      text: `Page ${page}/${Math.max(1, Math.ceil(queue.length / perPage))} • ${queue.length} songs total`,
    })
    .setTimestamp();
}

// ─── Voice / Playback Logic ──────────────────────────────────

async function connectToVoice(guildId: string, voiceChannel: VoiceChannel) {
  if (connections.has(guildId)) {
    const existing = getVoiceConnection(guildId);
    if (existing) return existing;
  }

  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator,
  });

  connections.set(guildId, connection);

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    if (!CONFIG.stayInChannel) {
      const queue = getServerQueue(guildId);
      if (!queue.isPlaying && !queue.isPaused) {
        setTimeout(() => {
          const conn = getVoiceConnection(guildId);
          if (conn && conn.state.status === VoiceConnectionStatus.Disconnected) {
            conn.destroy();
            connections.delete(guildId);
            servers.delete(guildId);
            players.delete(guildId);
          }
        }, 5000);
      }
    }
  });

  connection.on('error', (err) => {
    console.error(`Voice error in guild ${guildId}:`, err);
  });

  return connection;
}

async function playTrack(guildId: string) {
  const queue = getServerQueue(guildId);

  if (queue.queue.length === 0) {
    queue.isPlaying = false;
    queue.currentTrack = null;
    return;
  }

  const track = queue.queue.shift()!;

  // If looping the current song, push it back
  if (queue.loop === 'song') {
    queue.queue.unshift(track);
  }

  // If looping the queue, push it to the end
  if (queue.loop === 'queue') {
    queue.queue.push(track);
  }

  queue.currentTrack = track;
  queue.isPlaying = true;

  try {
    const audioStream = await stream(track.url, { quality: 2 });
    const resource = createAudioResource(audioStream.stream, {
      inputType: audioStream.type,
      inlineVolume: true,
    });

    let player = players.get(guildId);
    if (!player) {
      player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
      players.set(guildId, player);
    }

    // Set volume
    resource.volume!.setVolumeLogarithmic(queue.volume / 100);

    // Get connection and subscribe
    const connection = getVoiceConnection(guildId);
    if (connection) {
      connection.subscribe(player);
    }

    player.play(resource);

    // Send now playing message
    const channel = client.channels.cache.get(queue.textChannel);
    if (channel && 'send' in channel) {
      await (channel as any).send({ embeds: [nowPlayingEmbed(track, queue.queue.length)] });
    }

  } catch (err) {
    console.error(`Error playing track: ${track.title}`, err);
    queue.isPlaying = false;
    queue.currentTrack = null;

    const channel = client.channels.cache.get(queue.textChannel);
    if (channel && 'send' in channel) {
      await (channel as any).send({ content: `❌ Failed to play: **${track.title}**` });
    }

    // Try next track
    setTimeout(() => playTrack(guildId), 1000);
  }
}

function getPlayer(guildId: string) {
  if (!players.has(guildId)) {
    const player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
    players.set(guildId, player);

    player.on('stateChange', (oldState, newState) => {
      if (oldState.status === AudioPlayerStatus.Playing && newState.status === AudioPlayerStatus.Idle) {
        // Track finished, play next
        setTimeout(() => playTrack(guildId), 300);
      }
    });

    player.on('error', (err) => {
      console.error(`Player error in guild ${guildId}:`, err);
    });
  }
  return players.get(guildId)!;
}

// ─── YouTube Search ──────────────────────────────────────────

async function searchYouTube(query: string): Promise<QueueItem | null> {
  try {
    // Check if it's already a URL
    const isUrl = query.startsWith('http://') || query.startsWith('https://');

    let info;
    if (isUrl) {
      info = await video_info(query);
    } else {
      const results = await search(query, { limit: 1 });
      if (results.length === 0) return null;
      info = await video_info(results[0].url);
    }

    return {
      title: info.video_details.title || 'Unknown',
      url: info.video_details.url,
      duration: formatDuration(info.video_details.durationInSec),
      durationSec: info.video_details.durationInSec,
      thumbnail: info.video_details.thumbnails[0]?.url || '',
      requestedBy: '',
      requestedByAvatar: '',
    };
  } catch (err) {
    console.error('YouTube search error:', err);
    return null;
  }
}

// ─── Slash Commands ──────────────────────────────────────────

const commands = [
  new SlashCommandBuilder()
    .setName('play')
    .setDescription('▶️ Play a song from YouTube')
    .addStringOption(o => o.setName('query').setDescription('Song name or YouTube URL').setRequired(true)),

  new SlashCommandBuilder()
    .setName('skip')
    .setDescription('⏭️ Skip the current song'),

  new SlashCommandBuilder()
    .setName('pause')
    .setDescription('⏸️ Pause the current song'),

  new SlashCommandBuilder()
    .setName('resume')
    .setDescription('▶️ Resume paused song'),

  new SlashCommandBuilder()
    .setName('stop')
    .setDescription('⏹️ Stop and clear the queue'),

  new SlashCommandBuilder()
    .setName('queue')
    .setDescription('📋 Show the music queue')
    .addIntegerOption(o => o.setName('page').setDescription('Page number').setMinValue(1).setRequired(false)),

  new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('🎵 Show the currently playing song'),

  new SlashCommandBuilder()
    .setName('volume')
    .setDescription('🔊 Change the volume')
    .addIntegerOption(o => o.setName('level').setDescription('Volume 1-100').setMinValue(1).setMaxValue(150).setRequired(true)),

  new SlashCommandBuilder()
    .setName('loop')
    .setDescription('🔁 Toggle loop mode (off/song/queue)')
    .addStringOption(o =>
      o.setName('mode')
        .setDescription('Loop mode')
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Current Song', value: 'song' },
          { name: 'Entire Queue', value: 'queue' },
        )
        .setRequired(false)
    ),

  new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('🔀 Shuffle the queue'),

  new SlashCommandBuilder()
    .setName('remove')
    .setDescription('🗑️ Remove a song from queue')
    .addIntegerOption(o => o.setName('position').setDescription('Song position in queue').setMinValue(1).setRequired(true)),

  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('🧹 Clear the entire queue'),

  new SlashCommandBuilder()
    .setName('help')
    .setDescription('📖 Show all bot commands'),
];

// ─── Command Handlers ────────────────────────────────────────

async function handlePlay(interaction: ChatInputCommandInteraction) {
  const query = interaction.options.getString('query', true);
  const member = interaction.member as GuildMember;
  const voiceChannel = member.voice.channel;

  if (!voiceChannel) {
    await interaction.reply({ content: '❌ You must be in a voice channel to play music!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);
  queue.textChannel = interaction.channelId!;
  queue.voiceChannel = voiceChannel.id;

  await interaction.deferReply();

  // Search for the song
  const track = await searchYouTube(query);
  if (!track) {
    await interaction.editReply('❌ Could not find that song. Try a different search term.');
    return;
  }

  track.requestedBy = interaction.user.id;
  track.requestedByAvatar = interaction.user.avatar || '';

  if (queue.queue.length >= CONFIG.maxQueueSize) {
    await interaction.editReply(`❌ Queue is full! Max ${CONFIG.maxQueueSize} songs.`);
    return;
  }

  queue.queue.push(track);

  // Connect to voice if not connected
  await connectToVoice(interaction.guildId!, voiceChannel);

  // Start playing if not already
  if (!queue.isPlaying && !queue.isPaused) {
    getPlayer(interaction.guildId!);
    await playTrack(interaction.guildId!);
  }

  const embed = new EmbedBuilder()
    .setTitle('✅ Added to Queue')
    .setColor('#1DB954' as ColorResolvable)
    .setThumbnail(track.thumbnail)
    .addFields(
      { name: 'Title', value: track.title.length > 80 ? track.title.substring(0, 80) + '...' : track.title, inline: false },
      { name: 'Duration', value: track.duration, inline: true },
      { name: 'Position', value: queue.isPlaying || queue.isPaused ? `#${queue.queue.length + 1} in queue` : 'Up next!', inline: true },
    )
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}

async function handleSkip(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);

  if (!queue.isPlaying && !queue.isPaused) {
    await interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    return;
  }

  const player = getPlayer(interaction.guildId!);
  player.stop();

  queue.isPlaying = false;
  queue.isPaused = false;

  // Force play next
  setTimeout(() => playTrack(interaction.guildId!), 100);

  await interaction.reply('⏭️ Skipped!');
}

async function handlePause(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);

  if (!queue.isPlaying) {
    await interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    return;
  }

  const player = getPlayer(interaction.guildId!);
  player.pause();
  queue.isPaused = true;

  await interaction.reply('⏸️ Paused!');
}

async function handleResume(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);

  if (!queue.isPaused) {
    await interaction.reply({ content: '❌ Not paused!', ephemeral: true });
    return;
  }

  const player = getPlayer(interaction.guildId!);
  player.unpause();
  queue.isPaused = false;

  await interaction.reply('▶️ Resumed!');
}

async function handleStop(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const guildId = interaction.guildId!;
  const queue = getServerQueue(guildId);

  queue.queue = [];
  queue.isPlaying = false;
  queue.isPaused = false;
  queue.currentTrack = null;

  const player = players.get(guildId);
  if (player) player.stop();

  const connection = getVoiceConnection(guildId);
  if (connection) {
    connection.destroy();
    connections.delete(guildId);
  }

  servers.delete(guildId);
  players.delete(guildId);

  await interaction.reply('⏹️ Stopped and left the voice channel!');
}

async function handleQueue(interaction: ChatInputCommandInteraction) {
  const queue = getServerQueue(interaction.guildId!);
  const page = interaction.options.getInteger('page') || 1;

  if (queue.currentTrack === null && queue.queue.length === 0) {
    await interaction.reply({ content: '📭 Queue is empty! Use `/play <song>` to add songs.', ephemeral: true });
    return;
  }

  let description = '';

  // Show current track
  if (queue.currentTrack) {
    description += `🎵 **Now Playing:**\n[${queue.currentTrack.title}](${queue.currentTrack.url}) \`[${queue.currentTrack.duration}]\` — <@${queue.currentTrack.requestedBy}>\n\n`;
  }

  if (queue.queue.length > 0) {
    const perPage = 10;
    const start = (page - 1) * perPage;
    const end = start + perPage;
    const items = queue.queue.slice(start, end);

    description += `📋 **Up Next:**\n`;
    description += items.map((item, i) => {
      const num = start + i + 1;
      return `${num}. [${item.title}](${item.url}) \`[${item.duration}]\` — <@${item.requestedBy}>`;
    }).join('\n');

    if (queue.queue.length > end) {
      description += `\n... and ${queue.queue.length - end} more songs`;
    }
  }

  const embed = new EmbedBuilder()
    .setTitle('📋 Music Queue')
    .setDescription(description || 'No songs in queue')
    .setColor(CONFIG.color)
    .setFooter({ text: `${queue.queue.length} songs in queue • Loop: ${queue.loop}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

async function handleNowPlaying(interaction: ChatInputCommandInteraction) {
  const queue = getServerQueue(interaction.guildId!);

  if (!queue.currentTrack) {
    await interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    return;
  }

  const embed = nowPlayingEmbed(queue.currentTrack, queue.queue.length);
  embed.addFields({ name: 'Volume', value: `${queue.volume}%`, inline: true });
  embed.addFields({ name: 'Loop', value: queue.loop, inline: true });

  await interaction.reply({ embeds: [embed] });
}

async function handleVolume(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  const volume = interaction.options.getInteger('level', true);

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);
  queue.volume = volume;

  await interaction.reply(`🔊 Volume set to ${volume}%`);
}

async function handleLoop(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);
  const mode = interaction.options.getString('mode') as 'off' | 'song' | 'queue';

  if (mode) {
    queue.loop = mode;
  } else {
    // Cycle through modes
    const modes: Array<'off' | 'song' | 'queue'> = ['off', 'song', 'queue'];
    const currentIndex = modes.indexOf(queue.loop);
    queue.loop = modes[(currentIndex + 1) % modes.length];
  }

  const emojis: Record<string, string> = { off: '🔘', song: '🔂', queue: '🔁' };
  await interaction.reply(`${emojis[queue.loop]} Loop mode: **${queue.loop}**`);
}

async function handleShuffle(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);

  if (queue.queue.length < 2) {
    await interaction.reply({ content: '❌ Need at least 2 songs in queue to shuffle!', ephemeral: true });
    return;
  }

  // Fisher-Yates shuffle
  for (let i = queue.queue.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [queue.queue[i], queue.queue[j]] = [queue.queue[j], queue.queue[i]];
  }

  await interaction.reply('🔀 Queue shuffled!');
}

async function handleRemove(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  const position = interaction.options.getInteger('position', true);

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);

  if (position < 1 || position > queue.queue.length) {
    await interaction.reply({ content: `❌ Invalid position! Queue has ${queue.queue.length} songs.`, ephemeral: true });
    return;
  }

  const removed = queue.queue.splice(position - 1, 1)[0];
  await interaction.reply(`🗑️ Removed **${removed.title}** from the queue.`);
}

async function handleClear(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member.voice.channel) {
    await interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
    return;
  }

  const queue = getServerQueue(interaction.guildId!);
  const count = queue.queue.length;
  queue.queue = [];

  await interaction.reply(`🧹 Cleared ${count} songs from the queue!`);
}

async function handleHelp(interaction: ChatInputCommandInteraction) {
  const embed = new EmbedBuilder()
    .setTitle('🎵 YouTube Music Bot — Commands')
    .setColor(CONFIG.color)
    .addFields(
      { name: '/play <query>', value: '▶️ Play a song from YouTube', inline: true },
      { name: '/skip', value: '⏭️ Skip current song', inline: true },
      { name: '/pause', value: '⏸️ Pause music', inline: true },
      { name: '/resume', value: '▶️ Resume music', inline: true },
      { name: '/stop', value: '⏹️ Stop & leave channel', inline: true },
      { name: '/queue [page]', value: '📋 Show the queue', inline: true },
      { name: '/nowplaying', value: '🎵 Current song info', inline: true },
      { name: '/volume <1-150>', value: '🔊 Set volume', inline: true },
      { name: '/loop [mode]', value: '🔁 Toggle loop', inline: true },
      { name: '/shuffle', value: '🔀 Shuffle queue', inline: true },
      { name: '/remove <pos>', value: '🗑️ Remove song', inline: true },
      { name: '/clear', value: '🧹 Clear queue', inline: true },
    )
    .setFooter({ text: 'Type /play <song name or URL> to get started!' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── Event Handlers ──────────────────────────────────────────

client.on('ready', async () => {
  console.log(`✅ ${client.user?.tag} is online!`);
  console.log(`🎧 Serving ${client.guilds.cache.size} servers`);

  // Register slash commands
  if (CONFIG.clientId) {
    try {
      const rest = new REST({ version: '10' }).setToken(CONFIG.token);

      console.log('🔄 Registering slash commands...');
      await rest.put(
        Routes.applicationCommands(CONFIG.clientId),
        { body: commands.map(c => c.toJSON()) },
      );
      console.log('✅ Slash commands registered!');
    } catch (err) {
      console.error('❌ Failed to register commands:', err);
    }
  } else {
    console.log('⚠️ CLIENT_ID not set. Slash commands won\'t be registered automatically.');
    console.log('   Get CLIENT_ID from https://discord.com/developers/applications');
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    switch (interaction.commandName) {
      case 'play': await handlePlay(interaction); break;
      case 'skip': await handleSkip(interaction); break;
      case 'pause': await handlePause(interaction); break;
      case 'resume': await handleResume(interaction); break;
      case 'stop': await handleStop(interaction); break;
      case 'queue': await handleQueue(interaction); break;
      case 'nowplaying': await handleNowPlaying(interaction); break;
      case 'volume': await handleVolume(interaction); break;
      case 'loop': await handleLoop(interaction); break;
      case 'shuffle': await handleShuffle(interaction); break;
      case 'remove': await handleRemove(interaction); break;
      case 'clear': await handleClear(interaction); break;
      case 'help': await handleHelp(interaction); break;
    }
  } catch (err) {
    console.error('Command error:', err);
    const reply = { content: '❌ An error occurred!', ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply);
    } else {
      await interaction.reply(reply);
    }
  }
});

// Auto-leave empty voice channels
client.on('voiceStateUpdate', (oldState, newState) => {
  const guildId = oldState.guild.id;
  const connection = getVoiceConnection(guildId);
  if (!connection) return;

  const botMember = oldState.guild.members.me;
  if (!botMember) return;

  // Check if the bot is alone in the channel
  const voiceChannel = oldState.guild.channels.cache.get(botMember.voice.channelId || '');
  if (voiceChannel && voiceChannel.isVoiceBased()) {
    const members = (voiceChannel as VoiceChannel).members.filter(m => !m.user.bot);
    if (members.size === 0) {
      console.log(`🚪 Leaving empty voice channel in guild ${guildId}`);
      const queue = getServerQueue(guildId);
      queue.queue = [];
      queue.isPlaying = false;
      queue.isPaused = false;

      const player = players.get(guildId);
      if (player) player.stop();

      setTimeout(() => {
        connection.destroy();
        connections.delete(guildId);
        servers.delete(guildId);
        players.delete(guildId);
      }, 30000); // Leave after 30 seconds of being alone
    }
  }
});

// ─── Start ───────────────────────────────────────────────────

console.log(`
╔════════════════════════════════════════╗
║   🎵 Discord YouTube Music Bot       ║
╚════════════════════════════════════════╝
`);

client.login(CONFIG.token).catch((err) => {
  console.error('❌ Login failed:', err.message);
  process.exit(1);
});
